var index_app = angular.module('myApp', []);
index_app.controller('myCtrl', function($scope, $http) {
	
	 $scope.ad_post=function()
		{
			
	    	
	    	 
		    $http.get("/RentalsSpring/adpost/"+$scope.postad_name+"/"+$scope.postad_addr+"/"+$scope.postad_bhk+"/"+$scope.postad_price+"/"+$scope.postad_mob)
		    .success(function(response)
			{
		    	alert("Ad Successfully posted");
		    	document.getElementById("Insert_name").value="";
		    	document.getElementById("Insert_address").value="";
		    	document.getElementById("Insert_bhk").value="";
		    	document.getElementById("Insert_price").value="";
		    	document.getElementById("Insert_mobnumber").value="";
							
			});
	}

	 $scope.ad_update=function()
		{
			
	    	
	    	 
		    $http.get("/RentalsSpring/adupdate/"+$scope.adUpd_name+"/"+$scope.adUpd_addr+"/"+$scope.adUpd_bhk+"/"+$scope.adUpd_price+"/"+$scope.adUpd_mob)
		    .success(function(response)
			{
		    	alert("Ad Details Updated");
		    	document.getElementById("Update_mobnumber").value="";
		    	document.getElementById("Update_name").value="";
		    	document.getElementById("Update_address").value="";
		    	document.getElementById("Update_bhk").value="";
		    	document.getElementById("Update_price").value="";
							
			});
	}
	    
	 $scope.ad_delete=function()
		{
			
	    	
	    	 
		    $http.get("/RentalsSpring/addelete/"+$scope.adDel_mob)
		    .success(function(response)
			{
		    	
		    	$scope.deleteRecord=response;
		    	
		    	if($scope.deleteRecord=="")
		    		{
		    		alert("The Ad details are deleted successfully");
		    		document.getElementById("Delete_mobnumber").value="";
		    		}
		    	else
	    		{
		    		alert("The Ad is not found");
	    		}
					
		    	
		    	
		    	
		    	
		    	
							
			});
	}
	 
	 
	 $scope.ad_select=function()
		{
			
	    	
	    	 
		    $http.get("/RentalsSpring/adselect/"+$scope.adSel_addr)
		    .success(function(response)
			{
		    	
		    	
		    	$scope.result=response;
		    	if($scope.result=="")
		        {
		    		alert("Sorry!!Advertisements are not available for the searched location!!");
		    		
		        }	
		    	else{
		    		alert("Ads have been found!!!");
		    		document.getElementById("Select_address").value="";
		    	}
		    	});
	}
	 
	 
	 $scope.ad_selectAll=function()
		{
			
	    	
	    	 
		    $http.get("/RentalsSpring/addetails")
		    .success(function(response)
			{
		    	
		    	
		    	$scope.resultAll=response;
		    	
		    	
							
			});
	}
	
	 
});