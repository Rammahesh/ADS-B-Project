package com.rent.DAO;

import java.util.List;

import com.rent.bean.Advertisements;

public interface AdsDAO {
	 public List<Advertisements> getAd(String address);
	   
	   public void updateAd(Advertisements advertisements);
	   public void postAd(Advertisements advertisements);
	   public void deleteAd(String mobnumber);
	   public List<Advertisements> getAllAds();
}
