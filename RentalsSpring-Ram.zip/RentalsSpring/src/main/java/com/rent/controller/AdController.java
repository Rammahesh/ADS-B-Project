package com.rent.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.rent.bean.Advertisements;
import com.rent.DaoImpl.AdDaoImpl;

@RestController
public class AdController {


	@Autowired
	AdDaoImpl adDaoImpl;

	@RequestMapping("adpost/{name}/{address}/{bhk}/{price}/{mobnumber}")
    public void postAd(@PathVariable("name")String name,@PathVariable("address")String address,@PathVariable("bhk")String bhk,@PathVariable("price")String price,@PathVariable("mobnumber")String mobnumber, Model model)
	{
		adDaoImpl.postAd(name,address,bhk,price,mobnumber);
        alert("inserted Successfully");
	    System.out.println("insert successfully");
   }
	
	private void alert(String string) {
		// TODO Auto-generated method stub
		
	}
	@RequestMapping("adupdate/{name}/{address}/{bhk}/{price}/{mobnumber}")
    public void updateAd(@PathVariable("name")String name,@PathVariable("address")String address,@PathVariable("bhk")String bhk,@PathVariable("price")String price,@PathVariable("mobnumber")String mobnumber, Model model)
	{
		adDaoImpl.updateAd(name, address, bhk, price, mobnumber);
        
	    System.out.println("updated successfully");
   }
	
	
	@RequestMapping("addetails")
    public List<Advertisements> getAllAds(){
		List<Advertisements> advertisement= adDaoImpl.getAllAds();
      return advertisement;
    }
	
	
	
	@RequestMapping(value = "adselect/{address}", method = RequestMethod.GET)
	public @ResponseBody List<Advertisements> getAd(@PathVariable("address") String address,HttpServletRequest request, HttpServletResponse response,	Model model) 
	{

		List<Advertisements> advertisement= adDaoImpl.getAd(address, request, response);
	
	return advertisement;
	
	}
	
	@RequestMapping("addelete/{mobnumber}")
    public void deleteAd(@PathVariable("mobnumber")String mobnumber, Model model)
	{
		
	adDaoImpl.deleteAd(mobnumber);

	System.out.println("deleted successfully");
       
    }
   
}
