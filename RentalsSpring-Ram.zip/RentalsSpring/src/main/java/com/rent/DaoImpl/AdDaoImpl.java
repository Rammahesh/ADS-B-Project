package com.rent.DaoImpl;

import java.sql.Types;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rent.DAO.AdsDAO;
import com.rent.bean.Advertisements;
import com.rent.mapper.AdMapper;

public class AdDaoImpl implements AdsDAO {
private HttpServletRequest request;
private DataSource dataSource;
private JdbcTemplate jdbcTemplateObject;
public void setDataSource(DataSource dataSource) {
	 this.dataSource = dataSource;
	  this.jdbcTemplateObject = new JdbcTemplate(dataSource);
}
public void postAd(@PathVariable("name")String name,@PathVariable("address")String address,@PathVariable("bhk")String bhk,@PathVariable("price")String price,@PathVariable("mobnumber")String mobnumber)
{
try {
	   int[] types = new int[] {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
	   int i=jdbcTemplateObject.update("insert into xbbl5p1_rentals(NAME,ADDRESS,BHK,PRICE,MOBNUMBER)  values(?,?,?,?,?)", new Object[] {name,address,bhk,price,mobnumber},types);
	   if(i==1)
	   {
	     System.out.println(" INSERTED Succesfully");
	     alert("inserted Successfully");
	   } 
	}
	catch (Throwable fault) 
	{
	      System.out.println("Got error.  Returning null (404)");
	      fault.printStackTrace();
	                        
	}
}

public void updateAd(@PathVariable("name")String name,@PathVariable("address")String address,@PathVariable("bhk")String bhk,@PathVariable("price")String price,@PathVariable("mobnumber")String mobnumber)
{
try {
	   int[] types = new int[] {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
	   int i=jdbcTemplateObject.update("update xbbl5p1_rentals set name = ?, address = ?, bhk = ?, price = ? where mobnumber=?", new Object[] {name,address,bhk,price,mobnumber},types);
	   if(i==1)
	   {
	     System.out.println("Updated Succesfully");
	   } 
}
catch (Throwable fault) 
{
	  System.out.println("Got error.  Returning null (404)");
	  fault.printStackTrace();
}
}
	   
	   
	   
@RequestMapping(method = RequestMethod.GET)
public @ResponseBody List<Advertisements> getAllAds() {
List<Advertisements> list=null;
try {
list = jdbcTemplateObject.query("select * from xbbl5p1_rentals",new Object[] { },new AdMapper());
return list;
}
catch (Exception doe) {
alert("Error output");
System.out.println(" Null");
System.out.println(doe.getStackTrace());
return null;
}
}
	 
	   
@RequestMapping(method = RequestMethod.GET)
public @ResponseBody List<Advertisements> getAd(@PathVariable("address")String address,HttpServletRequest request, HttpServletResponse response) {
List<Advertisements> list=null;
			
try {
      address=address.toLowerCase();
	  list = jdbcTemplateObject.query("select * from xbbl5p1_rentals where lower(address) like %?%",new Object[] {address},new AdMapper());
      return list;
} catch (Exception doe) {
alert("Error output");
System.out.println("Null");
System.out.println(doe.getStackTrace());
return null;
}
}
public void deleteAd(@PathVariable("mobnumber")String mobnumber)
{
	  
try {
	    int[] types = new int[] {Types.VARCHAR};
	    int i=jdbcTemplateObject.update("delete from xbbl5p1_rentals where mobnumber=?", new Object[] {mobnumber},types);
	    if(i==1)
	    {
	      System.out.println(" Deleted Succesfully");
	    } 
}
catch (Throwable fault) 
{
	  System.out.println("Got error.  Returning null (404)");
	  fault.printStackTrace();
}
}
	   
private void alert(String string) {
		// TODO Auto-generated method stub
		
	}
	public List<Advertisements> getAd(String address) {
		// TODO Auto-generated method stub
		return null;
	}


	public void updateAd(Advertisements ad) {
		// TODO Auto-generated method stub

	}

	public void postAd(Advertisements ad) {
		// TODO Auto-generated method stub

	}

	

	
}
