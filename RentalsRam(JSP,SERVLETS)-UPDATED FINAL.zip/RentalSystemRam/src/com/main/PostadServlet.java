package com.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PostadServlet
 */
@WebServlet("/PostadServlet")
public class PostadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String oname=request.getParameter("ownername");
		String loc=request.getParameter("location");
		String bhk=request.getParameter("bhk");
		String price=request.getParameter("price");
		String pref=request.getParameter("prefer");
		String cno=request.getParameter("contactno");
		int count=1;
		PrintWriter out = response.getWriter(); 
		try {
			System.out.println("try");
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:inatp02","shobana","shobana");
			Statement ps=con.createStatement(); 
			String i="select count(*) as countofAds from house";
			ResultSet rs1= ps.executeQuery(i);
			if(rs1.next())
		    count = rs1.getInt(1);
			int c=count+1;
			System.out.println(c);
			String st="select * from house where ownername='"+oname+"'and location='"+loc+"'";
			ResultSet rs=ps.executeQuery(st);
			if(rs.next()){
			response.sendRedirect("Adfailure.jsp");
			}
			else
			{
				
			    String str="insert into house(hid,ownername,location,bhk,price,prefer,contactno) values('"+c+"','"+oname+"','"+loc+"',"+bhk+","+price+",'"+pref+"','"+cno+"')";
				rs=ps.executeQuery(str); 
				if(rs.next())
				{		
					response.sendRedirect("Adsuccess.jsp");
				}
				
			}
			con.close();
		
		}
		catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (SQLException e) {
			System.out.println(e);
		}  
	}

}
