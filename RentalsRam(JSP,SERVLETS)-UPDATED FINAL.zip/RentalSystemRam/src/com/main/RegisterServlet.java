package com.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uname=request.getParameter("username");
		String em=request.getParameter("email");
		String cnum=request.getParameter("cnumber");
		String fc=request.getParameter("familycount");
		String gen=request.getParameter("gender");
		String pword=request.getParameter("password");
		PrintWriter out = response.getWriter(); 
		try {
			System.out.println("try");
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:inatp02","shobana","shobana");
			Statement ps=con.createStatement(); 
			String st="select * from rentals where username='"+uname+"'";
			ResultSet rs=ps.executeQuery(st);
			if(rs.next()){
			out.println("<html><body><h2>Username already exists....Please Register with valid credentials</h2><a href='Login.jsp'>LOGIN</a></body></html>");
			}
			else
			{
			    String str="insert into rentals values('"+uname+"','"+em+"',"+cnum+","+fc+",'"+gen+"','"+pword+"')";
				rs=ps.executeQuery(str); 
				if(rs.next())
				{		
					out.println("<html><body><h2>Successfully Registered!!!You can Login now!!</h2><a href='Login.jsp'>LOGIN</a></body></html>");
				}
				
			}
			
		con.close();
		}
		catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (SQLException e) {
			System.out.println(e);
		}  
	}

}
