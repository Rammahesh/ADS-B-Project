package com.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.Bean;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String opt=request.getParameter("option");
		PrintWriter out = response.getWriter();
		Bean b=new Bean();
		try {
			
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:inatp02","shobana","shobana");
		Statement ps=con.createStatement(); 
		String str="select * from rentals where username='"+name+"' and password='"+password+"'";
		ResultSet rs=ps.executeQuery(str); 
		if(rs.next()){
			if(opt.equals("view ad")){
			response.sendRedirect("Userpage.jsp");
			b.setUsername(rs.getString("username"));
			b.setEmail(rs.getString("email"));
			b.setCnumber(rs.getLong("cnumber"));
			b.setFamilycount(rs.getInt("familycount"));
			b.setGender(rs.getString("gender"));
			b.setPassword(rs.getString("password")); 
		}
		else if(opt.equals("post ad")){
			b.setUsername(rs.getString("username"));
			response.sendRedirect("Ownerpage.jsp");
		}}
		else{
			out.println("<html><body><h2>INVALID USER...PLEASE REGISTER</h2><a href='Register.jsp'>REGISTER</a></body></html>");
		}
			con.close();
		} 
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}  
		
	}

}
