package com.bean;

public class Bean2 {
   private static String location;
   private static String bhk;
   private static String prefer;
   public static String getLocation() {
	return location;
}
public static void setLocation(String location) {
	Bean2.location = location;
}
public static String getBhk() {
	return bhk;
}
public static void setBhk(String bhk) {
	Bean2.bhk = bhk;
}
public static String getPrefer() {
	return prefer;
}
public static void setPrefer(String prefer) {
	Bean2.prefer = prefer;
}

}
