package com.bean;

public class Bean {
	private static String username;
	private static String email;
	private static long cnumber;
	private static int familycount;
	private static String gender;
	private static String password;
	public static String getUsername() {
		return username;
	}
	public static String getEmail() {
		return email;
	}
	public static long getCnumber() {
		return cnumber;
	}
	public static int getFamilycount() {
		return familycount;
	}
	public static String getGender() {
		return gender;
	}
	public static String getPassword() {
		return password;
	}
	public static void setUsername(String username) {
		Bean.username = username;
	}
	public static void setEmail(String email) {
		Bean.email = email;
	}
	public static void setCnumber(long cnumber) {
		Bean.cnumber = cnumber;
	}
	public static void setFamilycount(int familycount) {
		Bean.familycount = familycount;
	}
	public static void setGender(String gender) {
		Bean.gender = gender;
	}
	public static void setPassword(String password) {
		Bean.password = password;
	}
	
}
