package logic;

import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.Socket;

public class Senderjav {
public Senderjav(String latlngsrc,String port,String ip)
{
	 try
	    {
		 System.out.println("ip------"+ip);
	       // InetAddress ip=InetAddress.getLocalHost();
//	        Socket skt=new Socket(ip,Integer.parseInt(port));
//	        ObjectOutputStream oos=new ObjectOutputStream(skt.getOutputStream());
//	        oos.writeObject(latlngsrc);
//	        oos.close();
//	        skt.close();
	       // System.out.println("in senderjav------"+latlngsrc+"***"+port);
	        InetAddress ia=InetAddress.getByName("228.27.57.88");
	        MulticastSocket ms=new MulticastSocket(5566);
	        ms.joinGroup(ia);
//	        String st=latlngsrc;
	        
	        DatagramPacket dp=new DatagramPacket(latlngsrc.getBytes(), latlngsrc.length(), ia,5566);
	        ms.send(dp);
	        System.out.println("in senderjav=========="+dp+"====="+latlngsrc);
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    	System.out.println("unable to receive latlng in----senderjav");
	        System.out.println("you had been closed whether airport or aircraft else thread timed out");
	        System.out.println("socket connection failed");
	    }
}
}
