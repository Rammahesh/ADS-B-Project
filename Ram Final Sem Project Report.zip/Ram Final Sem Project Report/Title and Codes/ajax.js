
function getXMLHttpRequest()
{
  var xmlHttpReq = false;
  // to create XMLHttpRequest object in non-Microsoft browsers
  if (window.XMLHttpRequest) {
    xmlHttpReq = new XMLHttpRequest();
   // alert("1---"+xmlHttpReq);
  } else if (window.ActiveXObject) {
    try {
      // to create XMLHttpRequest object in later versions
      // of Internet Explorer
      xmlHttpReq = new ActiveXObject("Msxml2.XMLHTTP");
           } catch (exp1) {
      try {
        // to create XMLHttpRequest object in older versions
        // of Internet Explorer
        xmlHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
       
      } catch (exp2) {
    	  
        xmlHttpReq = false;
      }
    }
  }
 // alert("after http req*****"+xmlHttpReq);
  return xmlHttpReq;
}
/*
 * AJAX call starts with this function
 */
function makeRequest1(str1)
{
	var xmlHttpRequest = getXMLHttpRequest();
  xmlHttpRequest.onreadystatechange = getReadyStateHandler1(xmlHttpRequest);
  xmlHttpRequest.open("GET",str1,true);
  xmlHttpRequest.send();
}
function getReadyStateHandler1(xmlHttpRequest)
{
	//alert("----getready---"+xmlHttpRequest.readyState +xmlHttpRequest.status );
	return function()
	{
		if (xmlHttpRequest.readyState == 4)
		{
      		if (xmlHttpRequest.status == 200)
			{
			 	if((xmlHttpRequest.responseText).indexOf("$") > -1)
			 	{
//			 	
//			 		var split1=xmlHttpRequest.responseText;
//				 	var tbody;
//					var theader;
//					theader='<div>';
//					tbody=split1;
//					var tfooter='</div>';
//					
//					var dumm;
//					document.getElementById('dynamictabdiv').innerHTML = theader + tbody + tfooter;
					ajaxresponse1(xmlHttpRequest.responseText);
				}
			 	else if((xmlHttpRequest.responseText).indexOf("*") > -1)
			 	{
			 		//alert("inside else if");
			 		ajaxresponse2(xmlHttpRequest.responseText);
			 	}
			 		
			
		}
      		else
			{
	        	//alert("HTTP error " + xmlHttpRequest.status + ": " + xmlHttpRequest.statusText);
	      	}
	}
};
}
function makeRequest3(str1)
{
	var xmlHttpRequest = getXMLHttpRequest();
  xmlHttpRequest.onreadystatechange = getReadyStateHandler3(xmlHttpRequest);
  xmlHttpRequest.open("GET",str1,true);
  xmlHttpRequest.send();
}
function getReadyStateHandler3(xmlHttpRequest)
{
	//alert("----getready---"+xmlHttpRequest.readyState +xmlHttpRequest.status );
	return function()
	{
		if (xmlHttpRequest.readyState == 4)
		{
      		if (xmlHttpRequest.status == 200)
			{
 				if((xmlHttpRequest.responseText).indexOf("=") > -1)
 					{
			 	//alert(xmlHttpRequest.responseText);
			 	flightMoveResponse(xmlHttpRequest.responseText);
			}
		}
      		else
			{
	        	//alert("HTTP error " + xmlHttpRequest.status + ": " + xmlHttpRequest.statusText);
	      	}
	}
};
}
function makeRequest2(str2)
{
  var xmlHttpRequest = getXMLHttpRequest();
  xmlHttpRequest.onreadystatechange = getReadyStateHandler2(xmlHttpRequest);
  xmlHttpRequest.open("POST",str2,true);
  xmlHttpRequest.send();
}
function getReadyStateHandler2(xmlHttpRequest)
{
	//alert("----getready---"+xmlHttpRequest.readyState +xmlHttpRequest.status );
	return function()
	{
		if (xmlHttpRequest.readyState == 4)
		{
      		if (xmlHttpRequest.status == 200)
			{
			 				
		}
      		else
			{
	        //	alert("HTTP error " + xmlHttpRequest.status + ": " + xmlHttpRequest.statusText);
	      	}
	}
};
}