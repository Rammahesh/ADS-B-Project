package logic;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringTokenizer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jutils21.FrameWork;

public class Moving extends HttpServlet {
	public int tim;
	public int segment;
	public int i=0;
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		try {
			
		
		HttpSession ses = request.getSession(true);
		tim=Integer.parseInt(ses.getAttribute("time").toString());
		segment = tim * 60;
		//System.out.println("in moving-----"+tim+"----"+segment);
	    String latlng1 = request.getParameter("loc1");
		String latlng2 = request.getParameter("loc2");
		 System.out.println("in moving****"+latlng1+"****"+latlng2);
		String latlng11 = latlng1.replace("(", "").replace(")", "");
		String latlng22 = latlng2.replace("(", "").replace(")", "");
		StringTokenizer strtok1 = new StringTokenizer(latlng11, ",");
		StringTokenizer strtok2 = new StringTokenizer(latlng22, ",");
		Double lat1 = Double.parseDouble(strtok1.nextToken().toString());
		Double lng1 = Double.parseDouble(strtok1.nextToken().toString());
		Double lat2 = Double.parseDouble(strtok2.nextToken().toString());
		Double lng2 = Double.parseDouble(strtok2.nextToken().toString());
		System.out.println("in moving values----" + lat1 + " " + lng1 + " "
				+ lat2 + " " + lng2);
		
		Double latdiff;
		Double lngdiff;
		if (lat1 != null && lat2 != null) {
			if (lat1 <= lat2 && lng1 <= lng2) {
				latdiff = lat2 - lat1;
				lngdiff = lng2 - lng1;
				lat1 += (latdiff / (segment-i));
				lng1 += (lngdiff / (segment-i));
				System.out.println("in moving segment------"+i+"---"+segment+"--"+tim);
				i+=2;
				out.println(lat1 + "*" + lng1);
				System.out.println("in moving current craft postion------"+lat1+"---"+lng1);
			}
			else if(lat1.equals("infinity") && lng1.equals("infinity"))
			{
				out.println(lat1 + "*" + lng1);
				System.out.println("in moving----- latlng condition false");
			}
		
		}
		
        	
    	} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out
				.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

}
