package logic;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Map.Entry;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sun.org.apache.bcel.internal.generic.NEW;

public class cont1 extends HttpServlet {
	String time;
	String desti;
	ADSBREC recobj=new ADSBREC("call");

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession ses = request.getSession(true);
		String val1 = "", val2;
		//System.out.println("cont1 call1");
		val2=ADSBREC.srcportvec.lastElement().toString();
		if(!ADSBREC.srcportvec.isEmpty())
		{
		StringTokenizer stringtoken1 = new StringTokenizer(val2, "$");
		String srcloc = stringtoken1.nextToken();
		String port = stringtoken1.nextToken();
		String ip= stringtoken1.nextToken();
		//ses.setAttribute("portnum", port);
		out.print(srcloc+"$"+port+"$"+ip);
		}
		ADSBREC.srcportvec.clear();
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession ses = request.getSession(true);		
		String latilongi = request.getParameter("latlng");
		String source = request.getParameter("source");
		String pnm = request.getParameter("portnum");
		String ip=request.getParameter("ip");
		System.out.println("in cont1=----"+ip);
		//System.out.println("in sender--------" + pnm+"---"+latilongi.charAt(0));
		if(! latilongi.equals(null) & ! latilongi.equals(""))
		{
			Senderjav sen = new Senderjav(latilongi+"$"+source,pnm,ip);
		}

}
}
