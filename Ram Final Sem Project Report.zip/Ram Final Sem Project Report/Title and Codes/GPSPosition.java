package logic;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jutils21.FrameWork;

import com.sun.xml.internal.fastinfoset.util.StringArray;

public class GPSPosition extends HttpServlet implements Location {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			String req = request.getParameter("data");
			String reqtype = request.getParameter("reqtype");
			String ajaxResponse="";
			

			if (reqtype != null) {
				System.out.println("request typevalue------"+reqtype);
				
				if(!locInfoMap1.isEmpty())
				{
					
				//System.out.println("mapreq=======" + locInfoMap);
//				for (Map.Entry<String, HashMap<String, String>> entry : locInfoMap.entrySet())
//				{
//					
//					//System.out.println("IN 1ST MAP===="+entry.getKey() + "======="+ entry.getValue());
//					for(Map.Entry<String, String> entryin :entry.getValue().entrySet())
//					{
//						System.out.println("IN 2ND MAP====="+entry.getKey()+"==="+entryin.getKey() + "======="+ entryin.getValue());
//						if(ajaxResponse.equals(""))
//						ajaxResponse+=entry.getKey()+"="+entryin.getKey()+"*"+entryin.getValue();
//						else
//							ajaxResponse+="@@"+entry.getKey()+"="+entryin.getKey()+"*"+entryin.getValue();
//						
//					}
//					
//				}
					for (Map.Entry<String, String> entry : locInfoMap1.entrySet())
					{
						System.out.println("----inside for---->"+locInfoMap1);
						//System.out.println("IN 1ST MAP===="+entry.getKey() + "======="+ entry.getValue());
						
							System.out.println("IN MAP====="+entry.getKey()+"=========="+ entry.getValue());
							if(ajaxResponse.equals(""))
							ajaxResponse+=entry.getKey()+"="+entry.getValue();
							else
								ajaxResponse+="@@"+entry.getKey()+"="+entry.getValue();
							
						
						
					}
				//System.out.println("IN 2ND MAP====="+ajaxResponse);
					System.out.println("----ajaxresponse---->"+ajaxResponse);
				out.println(locInfoMap1.size()+"#"+ajaxResponse);
				}
				else{
					System.out.println("no new airport entry yet");
				}
			}
			else {
				String arr[] = req.split("@");
				//System.out.println("================" + req);
				String craft = arr[0];
				//System.out.println("================1111" + arr[0]);
				String craftnum = arr[1];
				String source = arr[2];
				String desti = arr[3];
				String lat = arr[4];
				String lng = arr[5];
				String location = lat + "@" + lng;
//				if (!locInfoMap.isEmpty()) {
//					if (locInfoMap.containsKey(source)) {
//						HashMap temp = locInfoMap.get(source);
//						temp.put(craftnum, location);
//						locInfoMap.put(source, temp);
//					}else{
//						HashMap hm = new HashMap();
//						hm.put(craftnum, location);
//						locInfoMap.put(source, hm);
//					}
//				} else {
//					HashMap hm = new HashMap();
//					hm.put(craftnum, location);
//					locInfoMap.put(source, hm);
//
//				}
				if (!locInfoMap1.isEmpty()) {
					
						
						locInfoMap1.put(craftnum,location+"-"+source+"-"+desti);
					
				} else {
					
					locInfoMap1.put(craftnum,location+"-"+source+"-"+desti);

				}
				//System.out.println("================>>>>>>>" + locInfoMap);
				//out.println("success in else");
			}
        	
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("-=-=-==-=-=-exception in GPS LOCATION=-=-=-=-=-=-=-");
			// TODO: handle exception
		}
	}

}
