package logic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

public interface Location {
	HashMap<String,HashMap<String,String>> locInfoMap=new HashMap<String,HashMap<String,String>>(); 
	//HashMap<String,String> temp=new HashMap<String,String>();
	TreeMap<String,String> locInfoMap1=new TreeMap<String,String>();
}
