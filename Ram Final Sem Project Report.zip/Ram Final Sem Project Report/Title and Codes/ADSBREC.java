package logic;

import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.Vector;

import org.omg.CORBA.PUBLIC_MEMBER;

public class ADSBREC extends Thread {
public static Vector srcportvec=new Vector();
HashMap srcportmap=new HashMap();
HashMap destim=new HashMap();
int pnum=5678;
public static HashMap crafthm=new HashMap();
	public ADSBREC()
	{
		//constructor used to run socket
		start();
	}
	public ADSBREC(String s)
	{
		//constructor used to communicate cont1 and use vector
 	}
		
	
	public void run() 
	{
		try 
		{
		ServerSocket sss=new ServerSocket(pnum);
		
		while(true)
		{
			System.out.println(" **********ADSBATCH on successfully****** "+pnum);
			Socket s=sss.accept();
			System.out.println("------------ADSBATCH receiver connected-----------");
			ObjectInputStream oip=new ObjectInputStream(s.getInputStream());
			String str=oip.readObject().toString();
			//System.out.println("------------"+str+"-----------");
				StringTokenizer strtok=new StringTokenizer(str, "$");
				String strtok1="",strtok2="",strtok3="",strtok4="",strtok5="",strtok6="";
				strtok1=strtok.nextToken();
				//System.out.println(strtok1);
				if(strtok1.equalsIgnoreCase("location"))
				{
					strtok2=strtok.nextToken();
					strtok3=strtok.nextToken();
					strtok4=strtok.nextToken();
				//  strtok2=sourceAirport strtok3=portnumber
				//	System.out.println("In StartReceiver sourceAirport and portnumber-----"+strtok2+" "+strtok3);
					srcportmap.put(strtok3, strtok2) ;
					srcportvec.addElement(strtok2+"$"+strtok3+"$"+strtok4);
				}
				if(strtok1.equalsIgnoreCase("craft"))
				{
					strtok2=strtok.nextToken();
					strtok3=strtok.nextToken();
					strtok4=strtok.nextToken();
					strtok5=strtok.nextToken();
					strtok6=strtok.nextToken();
				//strtok 2,3,4,5,6=craftnumber,source,destination, current craft latitude, longitude
					crafthm.put(strtok2+"$"+strtok3+"$"+strtok4  ,  strtok5+"$"+strtok6 );
					//System.out.println("In StartReceiver sourceAirport and portnumber-----"+strtok2+" "+strtok3);
					
				}
				//if()
				              
		}	
		
		}
		catch(Exception e){
		e.printStackTrace();	
		}
		}

	
	
}
