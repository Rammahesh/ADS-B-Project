package com.tra.deskdao;



import java.util.List;

import com.tra.deskbean.ServiceBean;

public interface ServiceDao {

	public List<ServiceBean> getAllOrders();
}
