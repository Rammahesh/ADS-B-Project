package com.tra.deskcontroller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.tra.deskimpl.*;
import com.tra.deskbean.*;

@RestController
@RequestMapping
public class ServiceController {
	
	@Autowired
	ServiceImpl impl;
	
	@RequestMapping(value="/order",method=RequestMethod.GET)
	public List<ServiceBean> getAllOrders() {
		List<ServiceBean> bean = impl.getAllOrders();
		if(bean==null) {
			System.out.println("No data found");
		}
		return bean;
		
	}
	
	@RequestMapping(value="/order/{id}",method=RequestMethod.GET)
	public List getCustomerOrder(@PathVariable("id") int id) {
		List order = impl.getCustomerOrder(id);
		return order;
	}
	
	@RequestMapping(value="/order",method=RequestMethod.POST)
	public int insertOrder(@RequestBody ServiceBean ser, Model model) {
		ServiceBean b=null;
		int id = impl.insertOrder(ser);
		model.addAttribute("order", b);
		return id;
	}
	
	@RequestMapping(value="/order",method=RequestMethod.PUT)
	public String update(@RequestBody ServiceBean ser,Model model) {
		ServiceBean g=null;
		String res = impl.updateOrder(ser);
		model.addAttribute("order",g);
		
		return res;
	}
	
	@RequestMapping(value="/order/{id}",method=RequestMethod.DELETE)
	public String deleteOrder(@PathVariable("id") int id) {

		String msg = impl.deleteOrder(id);
		if(msg.equals("successfully deleted"))
			return msg;
		else
			return "Record Doesn't Exist";
	}

	}

