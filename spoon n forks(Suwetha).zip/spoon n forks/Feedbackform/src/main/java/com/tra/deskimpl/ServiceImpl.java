package com.tra.deskimpl;



import java.sql.Types;

import java.util.List;
import java.util.Random;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.dao.support.DaoSupport;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;








import com.tra.deskdao.*;

import com.tra.mapper.*;
import com.tra.deskbean.*;

@Component
public class ServiceImpl  implements ServiceDao{

	JdbcTemplate jdbcTemplate;

	Random r = new Random();
	
	
	@Autowired
    public ServiceImpl(DataSource dataSource)
    {
		jdbcTemplate = new JdbcTemplate(dataSource);
    }
  
		
	
	
	public List<ServiceBean> getAllOrders() {
		List<ServiceBean> orders = null;
		
		try {
			orders = jdbcTemplate.query("select items_db.order_no,items_db.items,items_db.quantity from items_db",new Object[]{},new ServiceMapper());		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return orders;
	}
	
	public List<ServiceBean> getCustomerOrder(int order_no) {
		List<ServiceBean> order = null;
		try {

			order = jdbcTemplate.query("select items_db.order_no,items_db.items,items_db.quantity from items_db where order_no=?",new Object[]{order_no},new ServiceMapper());	
		}catch(Exception e) {
			e.printStackTrace();
		}
		return order;
	}
	
	public int insertOrder(ServiceBean ser) {
		 int order_no=0;
		 String status="";
		
		try {
			order_no = r.nextInt(1000);
			if(order_no!=0)
				status="success";
			
		jdbcTemplate.update("insert into orderno_gen values ("+order_no+",'"+status+"')");
			jdbcTemplate.update("insert into items_db values("+order_no+",'"+ser.getItems()+"','"+ser.getQuantity()+"')");	
			
		}catch(Exception e) {
			
			e.printStackTrace();
		}
		return order_no;
		
		
	}
	
	public String updateOrder(ServiceBean ser) {
		String res=null;
		try {
		//	jdbcTemplate.update("update orderno_gen set username='"+ser.getUsername()+"' where userid="+ser.getUserid()+"");
			System.out.println(ser.getOrder_no());
			jdbcTemplate.update("update items_db set items='"+ser.getItems()+"',quantity="+ser.getQuantity()+"where order_no="+ser.getOrder_no()+"");
		    res="success";
		  }catch(Exception e) {
			res="failure";
			e.printStackTrace();
		}
		return res;
	}
	
	public  String deleteOrder(int order_no) {
		String res=null;
		try {
			  jdbcTemplate.update("delete from orderno_gen where order_no='"+order_no+"'");
			  jdbcTemplate.update("delete from items_db where order_no='"+order_no+"'");
			res="successfully deleted";
		}
		catch(Exception e) {
			res="no record found";
		}
		
		return res;
	}
}
