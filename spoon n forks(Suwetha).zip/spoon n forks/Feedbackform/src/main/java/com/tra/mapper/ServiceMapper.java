package com.tra.mapper;



import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.tra.deskbean.*;

public class ServiceMapper implements RowMapper<ServiceBean>{

	public ServiceBean mapRow(ResultSet rs, int rowNum) throws SQLException {
	
		ServiceBean ser = new ServiceBean();
		
		//GCSDBean.setUserId(rs.getInt("user_id"));
		ser.setOrder_no(rs.getInt("order_no"));
		//ser.setStatus(rs.getString("status"));
		//System.out.println(rs.getString("username"));
		ser.setItems(rs.getString("items"));
		ser.setQuantity(rs.getInt("quantity"));
		
		return ser;
	}

}
