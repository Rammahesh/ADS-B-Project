angular.module('todoApp', []).controller('TodoListController', function() {
	var todoListController = this;
	todoListController.todos = [ {
		text : 'learn angular',
		done : true
	}, {
		text : 'build an angular app',
		done : false
	} ];

	todoListController.addTodo = function() {
		alert('test');
		todoListController.todos.push({
			text : todoListController.todoText,
			done : false
		});
		todoListController.todoText = '';
	};

	todoListController.remaining = function() {
		var count = 0;
		angular.forEach(todoListController.todos, function(todo) {
			count += todo.done ? 0 : 1;
		});
		return count;
	};

	todoListController.archive = function() {
		var oldTodos = todoListController.todos;
		todoListController.todos = [];
		angular.forEach(oldTodos, function(todo) {
			if (!todo.done)
				todoListController.todos.push(todo);
		});
	};
});
