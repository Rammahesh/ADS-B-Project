package com.training.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;








import com.training.daoimpl.IProductDAO;
import com.training.model.Products;

@RestController
@RequestMapping(value="/prod")
public class ProductController {

	@Autowired
	IProductDAO productDAOImpl;

	@RequestMapping(value="/productinsert",method=RequestMethod.POST)

    public void postProduct(@RequestBody Products prod) throws IOException
	{
		
	productDAOImpl.postProduct(prod);
	System.out.println("insert successfully");
        }
	
	
	
	
	
	@RequestMapping(value="/productdetails",method=RequestMethod.GET)
    public List<Products> getAllProducts( Model model){
		List<Products> product = productDAOImpl.getAllProducts();
        model.addAttribute("products", product);
        System.out.println(product);
      return product;
    }
	
	
	
	
	
	
   
    }
