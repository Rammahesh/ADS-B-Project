package com.training.DAO;

import java.util.List;

import com.training.model.Products;

public interface ProductsDAO {

	 public void postProduct(Products pt);
	 
	   public List<Products> getAllProducts();
	   }
