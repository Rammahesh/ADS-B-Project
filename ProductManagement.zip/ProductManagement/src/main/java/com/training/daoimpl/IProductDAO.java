package com.training.daoimpl;
import java.sql.Types;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.training.DAO.ProductsDAO;
import com.training.mapper.ProductMapper;
import com.training.model.Products;

@Component
public class IProductDAO implements ProductsDAO {
	
	private HttpServletRequest request;

	Products prod;
	
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;
	   @Autowired
	   public void setDataSource(DataSource dataSource) {
	      this.dataSource = dataSource;
	      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	   }

	

	    public void postProduct(Products prod)
		{
	    	System.out.println(prod);
	  
	        try {
	                                       
	         int i = jdbcTemplateObject.update("insert into t_products values('"+prod.getId()+"','"+prod.getCategory()+"','"+prod.getName()+"','"+prod.getDimension()+"','"+prod.getDescription()+"','"+prod.getColor()+"',"+prod.getRating()+","+prod.getPrice()+")");
	         
	         int j=jdbcTemplateObject.update("insert into t_seller values('"+prod.getId()+"','"+prod.getSeller_id()+"','"+prod.getSeller_name()+"',"+prod.getSeller_rating()+")");
             
	          
	          if((i==1)&&(j==1))
	                        {
	                        	
	                        System.out.println(" INSERT Succesfully");
	  
	                        } 
	            }
	        catch (Throwable fault) 
	        {
	                        System.out.println("Got error.  Returning null (404)");
	                        fault.printStackTrace();
	                        
	        }
		}
	   
	   
	   
	   
	   
		public  List<Products> getAllProducts() {
			
			List<Products> list=null;
			try {

				list = jdbcTemplateObject.query("select * from t_products join t_seller on t_products.product_id=t_seller.product_id",new Object[] { },new ProductMapper());
				System.out.println(list); 

				return list;
			} catch (Exception doe) {

				alert("Error output");
				System.out.println(" Null");

				System.out.println(doe.getStackTrace());

				return null;

			}

		}
	 
	  
	   
	   
	  
	   private void alert(String string) {
		// TODO Auto-generated method stub
		
	}



	public void postProducts(Products pt) {
		// TODO Auto-generated method stub
		
	}



	
	}


	   

	



	


