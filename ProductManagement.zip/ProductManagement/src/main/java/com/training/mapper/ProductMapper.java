package com.training.mapper;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.training.model.Products;

public class ProductMapper implements RowMapper<Products> {

	public Products mapRow(ResultSet rs, int rowNum) throws SQLException {
	      Products obj = new Products();
	      obj.setId(rs.getString("product_id"));
	      obj.setName(rs.getString("product_name"));
	      obj.setCategory(rs.getString("prod_category"));
	      obj.setDimension(rs.getString("prod_dimension"));
	      obj.setDescription(rs.getString("prod_description"));
	      obj.setColor(rs.getString("product_color"));
	      obj.setRating(rs.getInt("prod_rating"));
	      obj.setPrice(rs.getFloat("prod_price"));
	      obj.setSeller_id(rs.getString("seller_id"));
	      obj.setSeller_name(rs.getString("seller_name"));
	      obj.setSeller_rating(rs.getInt("seller_rating"));
	      return obj;
	   }
	
}


