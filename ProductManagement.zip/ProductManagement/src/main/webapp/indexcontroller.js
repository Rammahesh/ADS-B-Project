var index_app = angular.module('myApp', []);
index_app.controller('myCtrl', function($scope, $http) {
	
	
	$scope.reti = false;
	
	
	 $scope.product_insert=function()
		{
			
	    	
		   var values={ 
                   "id": document.getElementById("p_id").value,
                   "name": document.getElementById("p_name").value,
                   "category":document.getElementById("p_cat").value,
                   "dimension": document.getElementById("p_dim").value,
                   "description": document.getElementById("p_desc").value,
                   "color":document.getElementById("p_color").value,
                   "rating":document.getElementById("p_rating").value,
                   "price": document.getElementById("p_price").value,
                   "seller_id":document.getElementById("p_sid").value,
                   "seller_name":document.getElementById("p_sname").value,
                   "seller_rating":document.getElementById("p_srate").value
                   
                   } 
$http.post('/ProductManagement/prod/productinsert',values).success(function(response) 
           { 
	
       
           
           alert("product details inserted");

}); 
	}
	

	
	
	 $scope.product_retrieve=function()
		{
			
	    	$http.get('/ProductManagement/prod/productdetails')
		    .success(function(response)
			{
		    	
		    	
		    	$scope.result=response;
		    	$scope.reti = true;
							
			});
	}
});