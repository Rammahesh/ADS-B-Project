package com.rent.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.rent.bean.Advertisements;

public class AdMapper implements RowMapper<Advertisements> {
	public Advertisements mapRow(ResultSet rs, int rowNum) throws SQLException {
	      Advertisements obj = new Advertisements();
	      obj.setName(rs.getString("name"));
	      obj.setAddress(rs.getString("address"));
	      obj.setBhk(rs.getString("bhk"));
	      obj.setPrice(rs.getString("price"));
	      obj.setMobnumber(rs.getString("mobnumber"));
	      return obj;
	   }

}
